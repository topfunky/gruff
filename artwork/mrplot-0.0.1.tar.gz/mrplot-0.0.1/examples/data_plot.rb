# Copyright (c) 2005 Malte Harder, Harderware## Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:## The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

require 'mrplot'
require 'mrplot/magick'
require 'mrplot/plots/xy'

include MRPlot

def get_value_for_time(time)
  
  itime   = time.to_i
  hours   = itime/100
  minutes = itime%100
  
  return hours + (minutes/60.0), "%i:%i" % [hours, minutes]
end

# Rawdata array
raw_data = [[834,1641],[745,1739],[642,1832],[529,1928],[429,2020],[401,2056],[420,2047],[508,1955],[601,1843],[654,1732],[752,1632],[835,1610]]

# Create a new graphic context
gc = RMagickContext.new(Size.new(1024,768))

# Create title and description of the plot
title = Label.new("Data plot")
description = Label.new("Two data plots with sunrise/set times in Bremen/Germany (at the 15th of month)")

# Create the plot
plot = XYPlot.new(title,description)

# Create the datasets

sunrise = Array.new
sunset  = Array.new

# Convert raw data
raw_data.each_index do |index|
  
  rise_value, rise_label  = get_value_for_time(raw_data[index][0])
  set_value, set_label    = get_value_for_time(raw_data[index][1])
  
  sunrise << { :x => index+0.5, :y => rise_value, :label => rise_label  }
  sunset  << { :x => index+0.5, :y => set_value, :label => set_label  }
end

rise_set = DataSet.new(sunrise, "Sunrise")
set_set = DataSet.new(sunset, "Sunset")

# Add to plot
plot << rise_set
plot << set_set

rise_set.style.color = Color.new( 0.7,0.8,0.0 )
set_set.style.color = Color.new( 0.6,0.5,0.0 )

rise_set.style.print_values = true
set_set.style.print_values = true

# Use an image marker
rise_set.style.marker = :cross
set_set.style.marker = :cross

# Set the plot space
plot.space.xrange = 0..12
plot.space.yrange = 0..24

# Set the grid steps
plot.grid.xstep   = 1
plot.grid.ystep   = 1
plot.grid.xdiv    = 3
plot.grid.ydiv    = 3

# Set the grid style (solid light gray dashed lines and solid light blue subdivisions)
plot.grid.style.solid = true
plot.grid.style.set_color(Color.new(0.9,0.9,0.9))
plot.grid.style.dashed = [6,2]

plot.grid.division_style.solid = true
plot.grid.division_style.set_color(Color.new(0.95,0.95,0.99))

plot.axes.xlabel = "Month"
plot.axes.ylabel = "Time"
plot.axes.style.rotate_y = true
plot.axes.ysubstitution = Substitution.new { |x| x.to_i.to_s + "h" }
plot.axes.xsubstitution = Substitution.new { |x| ['J','F','M','A','M','J','J','A','S','O','N','D'][x.to_i]}

# Align the history to the top - right
plot.history.alignment = :top_right

# Draw the plot with a border of 60 at the sides and 100 at the top/bottom, no additinal plots
# draw axes AND grid below the plot
plot.draw(gc, Rect.new(0,0,1024,768), Border.new(100,100,60,60), Array.new, false, false)

# Write the image
gc.write("data_plot.png")

