# Copyright (c) 2005 Malte Harder, Harderware## Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:## The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

require 'mrplot'
require 'mrplot/magick'
require 'mrplot/plots/bar'

include MRPlot

# Create a new graphic context
gc = RMagickContext.new(Size.new(1024,768))

title = Label.new("Sales")
description = Label.new("A sample of what can be done with BarPlot", Border.new(15,5,5,5))

# Create the plot
plot = BarPlot.new(title,description)

# Create the datasets
sales      = [171,92,61,65,22,15,65,71,44,85,71,258]
profit     = [203.15,107.55,71.70,71.70,-10.50,59.75,71.70,83.65,-22.0,95.60,83.65,271.75]

s_dataset  = DataSet.new(sales, "Sales")
p_dataset  = DataSet.new(profit, "Profit")

s_dataset.style.fill_color = Color.new(0.7,0.9,0.0)
p_dataset.style.fill_color = Color.new(0.3,0.2,0.9)

# Add the datasets to the plot
plot << s_dataset
plot << p_dataset

plot.space.index_range = 0..sales.size-1
plot.space.yrange = -30..300

plot.space.spacing = 10
plot.space.set_spacing = 4

plot.grid.style.color = Color.new(0.9,0.9,0.99)
plot.grid.ystep = 20
plot.grid.ydiv  = 3
plot.grid.division_style.color = Color.new(0.95,0.95,0.95)

plot.axes.ystep   = 20
plot.axes.labels  = ["J/04","F/04","M/04","A/04","J/04","J/04","A/04","S/04","O/04","N/04","D/04","J/05"]
plot.axes.label   = "Month"

plot.axes.ysubstitution = Substitution.new() { |x| x.to_i.to_s + "M" }

plot.history.alignment = :top_left

plot.draw(gc, Rect.new(0,0,1024,768), Border.new(100,100,100,60))

gc.write("bar_chart.png")