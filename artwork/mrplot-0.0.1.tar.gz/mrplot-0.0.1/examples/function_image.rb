# Copyright (c) 2005 Malte Harder, Harderware## Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:## The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

require 'mrplot'
require 'mrplot/magick'
require 'mrplot/plots/xy'

include MRPlot

# Create a new graphic context
gc = RMagickContext.new(Size.new(1024,768))

# Create title and description of the plot
title = Label.new("Function plot")
description = Label.new("A function with image marker")

# Create the plot
plot = XYPlot.new(title,description)

# Create the functions datasets

dataset = DataSet.new(ContinousData.new  { |x| Math.sin(x)*Math.log((0.3*x).abs) }, "y = sin(x)*ln(|0.3x|)")

# Add to plot
plot << dataset

dataset.style.color = Color.new( 0,0,1.0 )

# Use an image marker
dataset.style.marker = :image
dataset.style.marker_image = "aqua.png"
dataset.style.hide_connections = true

# Set the plot space
plot.space.xrange = -5.6..5.6
plot.space.yrange = -3.3..3.3
plot.space.res    = 80

# Set the grid steps
plot.grid.xstep   = 0.5
plot.grid.ystep   = 0.5
plot.grid.xdiv    = 3
plot.grid.ydiv    = 3

# Set the grid style (solid light gray dashed lines and solid light blue subdivisions)
plot.grid.style.solid = true
plot.grid.style.set_color(Color.new(0.9,0.9,0.9))
plot.grid.style.dashed = [6,2]

plot.grid.division_style.solid = true
plot.grid.division_style.set_color(Color.new(0.95,0.95,0.99))

# Align the history to the top - left
plot.history.alignment = :top_left

# Draw the plot with a border of 60 at the sides and 100 at the top/bottom, no additinal plots
# draw axes AND grid below the plot
plot.draw(gc, Rect.new(0,0,1024,768), Border.new(100,100,60,60), Array.new, false, false)

# Write the image
gc.write("function_image.png")

