# Copyright (c) 2005 Malte Harder, Harderware
#
# Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:
#
# The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

require 'mrplot/helpers'

# mrplot is a general purpose plotting library. It is written entirely in ruby
# and is very extendable (backends, plot types, ...).
module MRPlot

  VERSION = 0.01
  
  include MRPHelpers
  
  # GraphicContext is the base class for all backends. If you use it as context
  # your plots will be printed to the console as commands. If you want to write 
  # your own backend you need to overwrite at least all functions starting with
  # atom_. For optimisation it is recommend to overwrite the other draw
  # methods too. With mrplot comes the RMagickContext which is a binding
  # to the rmagick/imagemagick library.
  #
  # Which styles are supported by a backend varies but you should support the
  # following styles (and accept the classes as written here):
  #
  # color (Color):: The stroke color of an object (the fill color if there is no stroke)
  # fill_color (Color):: The fill color of an object
  # line_width (Numeric) :: The line/stroke width of an object
  #
  # These styles are only used in atom_ methods which are handling with text
  # font (String):: The font of a text
  # font_size (Numeric):: The font size of a text
  # font_style (String):: The font style of a text
  # 
  # The following styles are only used within the marker/arrowhead atoms
  #
  # marker (Symbol):: The marker type which will be used
  # marker_image (String) :: Path to a marker image
  # arrow_head (Symbol) :: The style of the arrowhead used
  #
  # Which arrowheads/markers are supported is depending on the context you use.
  #
  class GraphicContext
    
    attr_accessor :windowspace, :clip
    
    # Creates a new context
    def initialize(size = Size.new(0,0))
      @size         = size
      @clip         = false
      @windowspace  = Rect.fromsize(size)
    end
    
    # Draws a placeholder rect to the context
    #
    # The method is only needed for debugging purposes
    def placeholder(rect)
      puts "Placeholder #{rect}"
    end
    
    # Draw Atoms
    
    # Draw a string at a given point. The style parameter depends on the context.
    # Not every style parameter is supported by every context.
    #
    # rel and rel_v are used to specify how the string is aligned to the given point
    #
    # rel can be :left, :center, :right
    # rel_v can be :top, :center, :bottom
    #
    # The rotation parameter is a MRPHelpers::Rotation object which specifies a rotation around
    # a point.
    #
    def atom_text(string, point, style, rel = :left, rel_v = :bottom, rotation=nil)
      puts "Text \"#{string}\" #{point} [#{style}]"
    end
    
    # Get the size of a styled string
    #
    # <b>The size can include the descent! </b>
    def atom_textsize(string, style)
      return Size.new(0,0)
    end
    
    # Draws a single line from point_start to point_end
    def atom_drawline(point_start, point_end, style)
      puts "Line #{point_start} #{point_end}, [#{style}]"
    end
    
    # Draws a filled rectangle with the dimensions of rect
    def atom_fillrect(rect, style)
      puts "Fillrect #{rect}, [#{style}]"
    end
    
    # Draws the outline of a rectangle with the dimensions of rect
    def atom_drawrect(rect, style)
      puts "Fillrect #{rect}, [#{style}]"
    end
    
    # Draws a marker at the position point
    def atom_marker(point, style)
      puts "Marker #{point} [#{style}]"
    end
    
    # Draws an arrowhead at the position point with the align :xarrow or :yarrow
    def atom_arrow_head(point, align, style)
      puts "Arrowhead #{point}, #{top} [#{style}]"
    end
    
    # Draw Functions
    
    # Used to draw multiple connected lines with one command
    # 
    # Can be overwritten for speed reasons. The standard implementation just loops over an array of points
    # and calls atom_drawline(points[i-1], points[i], style)
    def draw_line_segments(points, style)
      1.upto(points.size-1) do |i|
        atom_drawline(points[i-1], points[i], style)
      end
    end
    
    # Used to draw multiple lines in with one command
    # 
    # Can be overwritten for speed reasons.
    def draw_lines(points, style)
      (0 .. points.size-1).step(2) do |i|
        atom_drawline(points[i], points[i+1], style)
      end
    end
    
    # Draw multiple markers at once
    def draw_markers(points, style)
      points.each { |point| atom_marker(point, style) }
    end
    
    # Draw multiple strings at once
    def text_array(string, point, style, rel = :left, rel_v = :bottom, rotation=nil)
        string.each_index { |i| atom_text(string[i], point[i], style, rel, rel_v, rotation) }
    end
    
    # Draw a text centered within a rectangle
    def text_inrect(string, rect, style, rotation=nil)
      if string.class == Array then
        string.each_index { |i| text_inrect(string[i], rect[i], style, rotation) }
      else
        position  = rect.origin
              
        position.x += (rect.width/2)
        position.y += (rect.height/2)

        atom_text(string, position, style, :center, :center, rotation)
      end
    end
        
    # Get the core context. This depends on the choosen graphics context. The MagickContext for example
    # returns a draw object.
    def corecontext
      $>
    end

    # Transform a point from windowspace (which has a bottom, left = 0,0 coordinate system) to context
    # space (top, left = 0,0). If your backend also supports a coordinate system like the windowspace
    # you don't need to call it.
    def transform(point)
      scale_x = 1
      scale_y = -1
      trans_x = @windowspace.x
      trans_y = @windowspace.y + @windowspace.height
      
      return Point.new((point.x*scale_x)+trans_x, (point.y*scale_y)+trans_y)
    end
    
    # Does the same as transform but transforms from contextspace to windowspace
    def inverse_transform(point)
      scale_x = 1
      scale_y = -1
      trans_x = @windowspace.x
      trans_y = @windowspace.y + @windowspace.height
      
      return Point.new((point.x-trans_x)/scale_x, (point.y-trans_y)/scale_y)
    end
  
  end
    
  # The plot class is the base for all graphs. There are different subclasses for different plots styles
  # like BarPlot or XYPlot. The plot base class takes care of drawing the axis, grid, history, title and
  # description. Every plot has also a PlotSpace which transforms coordinates from plot space to window space
  # Using the plot's draw method you can also draw different types of plots at the same time. These plots will
  # share one coordinate system/one grid etc.   
  class Plot
  
    # PlotObject
    attr_accessor :axes, :grid, :history, :space, :title, :description
    # HistorySymbol
    attr_accessor :history_symbol
    # Array
    attr_reader   :datasets, :figures
    
    def initialize(title = nil, description = nil)
      # Create an empty array of data sets
      @datasets    = Array.new 
      
      # Projects coordinates from plot to window space & contains all clippings
      @space          = PlotSpace.new
      
      # Create new standard axes, grid and figures (drawn in window/plot space)
      @axes           = Axes.new
      @grid           = Grid.new
      @figures        = Array.new

      # Create a new history and history symbol
      @history        = History.new
      @history_symbol = HistorySymbol.new
      
      if !title 
        @title = Label.new("Untitled Plot")
      else
        @title          = title
      end
      
      @description    = description
    end
    
    # Add a new dataset to the plot. Every dataset has a data container: discrete data (Array, Enumerable) 
    # or a function (ContinousData).
    def add_dataset(dataset)
      @datasets << dataset
    end
    
    alias << add_dataset 
    
    # Draw the plot to a context within the bounds given by rect. The rect without the border is the windowspace.
    # If you pass an array of plots they will be drawn (without grid, axes ...) on top of the receiving plot.
    def draw(context, rect, border, plots=Array.new, axes_top = true, grid_top = false)
      # Exchange top/bottom in the border, because the window space itself is set in context space coordinates
      border.top, border.bottom   = border.bottom, border.top
      # Set the windowspace to the rect and use it
      context.windowspace         = rect.cut(border)
      # And change back because now everything is in window space
      border.top, border.bottom   = border.bottom, border.top
      
      # Sort the figures
      grid_figures                = Array.new
      plot_figures                = Array.new
      axes_figures                = Array.new
      top_figures                 = Array.new
      
      @figures.each do |figure|  
        case figure.layer
          when :grid
            grid_figures << figure
          when :plots
            plot_figures << figure
          when :axes
            axes_figures << figure
          when :figure
            top_figures << figure
        end
      end
      
      # Draw the grid at first (if not set to top)
      if !grid_top
        grid_figures.each{ |figure| figure.draw(context, @space)}
        @grid.draw(context, @space) if @grid
      end
      
      if !axes_top
        axes_figures.each{ |figure| figure.draw(context, @space)}
        @axes.draw(context, @space) if @axes
      end
      
      # Draw all plots
      plot_figures.each{ |figure| figure.draw(context, @space)}
      context.clip = true
      draw_naked(context)
      plots.each { |plot| plot.draw_naked(context) }
      context.clip = false
      
      if grid_top
        grid_figures.each{ |figure| figure.draw(context, @space)}
        @grid.draw(context, @space) if @grid
      end
      
      # Draw axes
      if axes_top
        axes_figures.each{ |figure| figure.draw(context, @space)}
        @axes.draw(context, @space) if @axes
      end
      
      # Draw all figures and labels
      top_figures.each{ |figure| figure.draw(context, @space)}
  
      # Draw the history
      if @history
        all_plots = Array.new
        
        all_plots << self
        all_plots.insert(1, *plots)
        
        @history.plots = all_plots
        @history.draw(context, @space) 
      end
              
      # Draw
      if @title
        neworigin = context.inverse_transform(Point.new(rect.x,rect.y))
        @title.rect = Rect.new(neworigin.x,neworigin.y-border.top, rect.width, border.top)
        @title.draw(context, @space)
      end
      
      if @description
        neworigin = context.inverse_transform(Point.new(rect.x,rect.y+rect.height))
        @description.rect = Rect.new(neworigin.x,neworigin.y, rect.width, border.bottom)  
        @description.draw(context, @space)
      end
      
    end

    # Draw the plot, overwrite this method to implement your own plot type
    def draw_naked(context)   
      context.placeholder(Rect.new(0,0,context.windowspace.width,context.windowspace.height))
    end
    
  end
  
  # This class does the transformation from plot to window space. You can change the ranges of the plot
  # using this class. It is also possible to extend plots by replacing the space attribute of a plot with
  # an instance of another plot space (with logarithmic scale for example) 
  class PlotSpace
    
    def transform_to_unitspace(pointnd)
      return pointnd
    end
    
    def transform_to_plotspace(pointnd)
      return pointnd
    end

    # Transforms a point to unit space using the transform_to_unitspace(pointnd) method. You can overwrite
    # the transform_to_unitspace(pointnd) or this method in a subclass 
    def transform_to_windowspace(pointnd, windowspace)
      point2d = transform_to_unitspace(pointnd)
      Point.new(point2d.x*windowspace.width, point2d.y*windowspace.height)
    end
    
  end
  
  # A PlotObject is the base class of any object drawn to the plot
  class PlotObject
  
    attr_reader :style
  
    def initialize
      @visible  = true
      @style    = Style.new
    end
    
    def visible?
      @visible
    end
    
    def show
      @visible = true
    end
    
    def hide
      @visible = false
    end
    
    # The plot object handles the visibility, call this method to draw the object to a context.
    def draw(context, space)
      if visible?
        draw_object(context, space)
      end
    end
  
  protected
    # Overwrite this method in a subclass
    def draw_object(context, space)

    end  
    
  end
  
  # The standard history lists all datasets with the corresponding history symbol. 
  # The datasets are grouped to the plot.
  class History < PlotObject
    
    attr_accessor :plots, :border, :position, :alignment
    
    SPACING = 4
    
    # The position is relative to the corner specified with the alignment argument 
    # (:top_right, :top_left, :bottom_right, :bottom_left)
    def initialize(border = Border.new(SPACING,SPACING,SPACING,SPACING), position = Point.new(10,10), alignment = :top_right)
      super()
      
      @plots    = Array.new
      @border   = border
      @position = position
      @alignment = alignment
      
      # Standard style
      @style.symbol_size  = 14
      @style.fill_color   = Color.new(1,1,1)
      @style.color        = Color.new(0,0,0)
      @style.line_width   = 1
    end
    
  protected
    
    def get_height(size, style)
      if size.height < style.symbol_size
        return style.symbol_size
      else
        return size.height
      end
    end
    
    def draw_object(context, space)
      height      = @border.top+@border.bottom
      row_height  = 0
      width       = 0
      # Determine the size of the history frame
      plots.each do |plot|
        size        = context.atom_textsize(plot.title.string, @style)
        
        # Do only once as font style is the same everywhere
        if row_height == 0
          # Check which height is bigger
          row_height = get_height(size, style)
        end
        
        # Print plot headers only if multiple plots were drawn
        if plots.size > 1 then
          height      += row_height + (SPACING * 1.5).round
          
          cur_width   = size.width
          width       = cur_width if cur_width > width
        end
        
        # Loop through all datasets
        plot.datasets.each do |dataset|
          size        = context.atom_textsize(dataset.label, @style)
                          
          cur_width   = size.width + @style.symbol_size + SPACING
          width       = cur_width if cur_width > width
         
          height      += row_height + SPACING
        end
      end
      
      # Add the border to the history frame
      width += @border.left + @border.right
      # Correct the last spacing
      height -= SPACING
      
      # Translate the position
      position = @position
      if @alignment == :top_right then
        position = Point.new(context.windowspace.width-width-position.x, context.windowspace.height-height-position.y)
      elsif @alignment == :top_left then
        position = Point.new(position.x, context.windowspace.height-height-position.y)
      elsif @alignment == :bottom_right then
        position = Point.new(context.windowspace.width-width-position.x, position.y)
      end
          
      # Draw the history frame
      context.atom_fillrect(Rect.new(position.x, position.y, width, height), @style)
      top_pos = Point.new(position.x+@border.left, position.y+height-@border.top)
      
      # Draw all plot and dataset infos
      plots.each do |plot|
        # Draw plot header only if multiple plots were drawn
        if plots.size > 1 then
          size        = context.atom_textsize(plot.title.string, @style)
        
          text_pos    = Point.new(top_pos.x, top_pos.y - row_height/2 + size.height/2)
          text_pos.cap!
          
          text_pos.y -= size.height
          context.atom_text(plot.title.string, text_pos, @style)
          
          top_pos.x   = position.x+@border.left
          top_pos.y   -= row_height + SPACING
        end          
        plot.datasets.each do |dataset|
          size        = context.atom_textsize(dataset.label, @style)
        
          symbol_pos  = Point.new(top_pos.x,                     top_pos.y - (row_height*1/2) - @style.symbol_size/2)
          text_pos    = Point.new(top_pos.x + @style.symbol_size + SPACING, top_pos.y - row_height/2 + size.height/2)
          
          symbol_pos.cap!
          text_pos.cap!
          
          plot.history_symbol.draw(dataset, context, symbol_pos, @style)
        
          text_pos.y -= size.height
          context.atom_text(dataset.label, text_pos, @style)
          
          top_pos.x   = position.x+@border.left
          top_pos.y   -= row_height + SPACING
        end
        # Plot seperation
        top_pos.y   -= (SPACING * 0.5).round
      end
      
    end
    
  end
  
  # The HistroySymbol is drawn in front of every dataset's label in the history. The standard symbol uses the dataset color 
  # as the fill color of a square.
  class HistorySymbol 
    
    def draw(dataset, context, text_pos, style)
      symbolstyle             = Style.new
      symbolstyle.fill_color  = dataset.style.color
      symbolstyle.color       = Color.new(0,0,0)
      
      symbolrect              = Rect.new(text_pos.x, text_pos.y, style.symbol_size, style.symbol_size)
      
      context.atom_fillrect(symbolrect, symbolstyle)
    end
    
  end
  
  # The Axes class is the base class for any axes class.
  class Axes < PlotObject
  
  end
  
  # The Grid class is the base class for any grid class.
  class Grid < PlotObject
  
  end

  # A figure is a non-plot object. Figure is the base class for any figure, like border, label.... Every figure has a layer
  # where it will be placed below. The layer can be :figure, :plots, :axes, :grids.
  class Figure < PlotObject
    
    attr_accessor :layer, :rect
    
    def initialize(rect)
      @layer  = :figure
      @rect   = rect
      super()
    end
    
    def draw_object(context, projection)
      context.placeholder(rect)
    end
    
  end
  
  # CoreFigure is a class to add backend specific drawings to the plot.
  class CoreFigure < Figure
    
    # :call-seq:
    #   new() { |core_context| ... }
    #
    # Pass a block which draws on the core_context
    def initialize(&core_function)
      @core_function = core_function
      super(Rect.new(0,0,0,0))
    end 
    
    def draw_object(context, projection)
      @core_function.call(context.corecontext)
    end
    
  end
  
  class Label < Figure
    
    attr_accessor :string, :border
    
    # Specify a border and a rect, the string will be drawn horizontally and vertically centered
    def initialize(string, border = Border.new(5,5,5,5), rect = Rect.new(0,0,0,0))
      @string = string
      @border = border
      super(rect)
    end
    
    def draw_object(context, projection)
      context.text_inrect(@string, @rect.cut(@border), @style)
    end
    
  end
  
  # A simple border with transparent fill-color
  class Frame < Figure
    def draw_object(context,projection)
      context.atom_drawrect(@rect, @style)
    end
  end
  
  # A DataSet contains data as discrete (Array) or continous (ContinousData) content. Every DataSet has also a label (used
  # in the history and a style (which determines the color of the DataSet).
  class DataSet

    attr_reader   :style
    attr_accessor :content, :label
        
    def initialize(content = Array.new, label = "Untitled Set", style = Style.new)
      @content  = content
      @label    = label
      @style    = style
    end
        
  end
  
  # ContinousData is a wrapper around a function. Usind continous data, the plot has the same access 
  # to a function as to an array (by using the [] operator).
  class ContinousData
    # call-seq:
    #   new() { |p1,p2...pn ... }
    def initialize(&continous_function)
      @continous_function = continous_function
    end
    
    def slice(*index)
      @continous_function.call(*index)
    end
    
    alias [] slice
  end
  
end