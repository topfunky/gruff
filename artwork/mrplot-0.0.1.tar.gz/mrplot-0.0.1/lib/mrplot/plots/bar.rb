module MRPlot
  # A classic bar plot. Uses BarSpace as plot space, BarAxes as axes, BarGrid as grid
  # and BarHistorySymbol as histroy symbol (because the standard symbol uses color and
  # not fill_color to fill the symbol)
  class BarPlot < Plot
  
    def initialize(title = nil, description = nil)
      super(title,description)
      
      @space          = BarSpace.new
      
      @axes           = BarAxes.new
      @grid           = BarGrid.new
      
      @history_symbol = BarHistorySymbol.new
    end
  
    def draw_naked(context)
    
      @datasets.each_index do |dataset_index|
        
        dataset = @datasets[dataset_index]
        content = dataset.content
        
        @space.index_range.step(1) do |index|
          
          begin
            data_value = content[index]
          rescue
            data_value = 0
          end
     
          data_rect = @space.transform_to_windowspace(index, data_value, dataset_index, @datasets.size, context.windowspace)
          
          # Draw the rectangle
          context.atom_fillrect(data_rect, dataset.style)
          
        end
      end
    end
  end
  
  # BarSpace is a little bit different from standard spaces as you can see. The yrange
  # is the same as in the XYSpace. The index range is the range of the dataset's content
  # array which will be shown. Spacing is the spacing between to indices and set spacing
  # the spacing between two datasets
  class BarSpace < PlotSpace
  
    attr_accessor :yrange, :index_range, :spacing, :set_spacing
    
    def initialize(index_range = 0..0, yrange = 0..100, spacing = 15, set_spacing=6)
      @index_range, @yrange = index_range, yrange
      @spacing, @set_spacing = spacing, set_spacing
    end
    
    def get_value(data_value, windowspace)
      return (data_value.to_f   - @yrange.first)/(@yrange.last - @yrange.first)*windowspace.height
    end
    
    def transform_to_windowspace(data_index, data_value, set_index, num_of_sets, windowspace)
      # Prepare transformation
      rect      = Rect.new(0,0,0,0)
      data_pos  = data_index - index_range.first
      
      # Plot transformation
      unit_size = windowspace.width.to_f/(index_range.last - index_range.first + 1)
      # Calculate general x pos with spacing
      rect.origin.x       = (unit_size*data_pos) + spacing
      # Calculate dataset position
      rect.size.width     = (unit_size-(2*spacing)) / num_of_sets
      rect.origin.x      += (rect.width+set_spacing)*set_index
      
      rect.origin.y       = get_value(0,          windowspace)
      rect.size.height    = get_value(data_value, windowspace) - rect.y
      
      rect.origin.cap!
      rect.size.width = rect.size.width.round
      rect.size.height= rect.size.height.round
      
      # Window transformation
      return rect
    end
  end
  
  # The BarGrid is the same as XYGrid but it has only horizontal lines/markers
  class BarGrid < Grid
  
    attr_accessor :ystep, :ydiv
    attr_reader   :division_style
  
    def initialize(ystep=10, ydiv=1)
      # Init the super class
      super()
      # Init attributes
      @ystep, @ydiv = ystep, ydiv
      # Set the standard style
      @division_style       = Style.new
    end
    
  protected
  
    def draw_object(context, space)
    
      # Calculate the division step
      dstepy  = @ystep/(@ydiv+1.0)
      # Calculate the offset to put the ticks in the correct position
      yof     = dstepy - (space.yrange.first.to_f % dstepy)
      
      # Calculate the marker/line ranges
      rangey = (space.yrange.first.to_f + yof) .. space.yrange.last.to_f
      
      # Store solid lines in an array
      line_points             = Array.new
      division_line_points    = Array.new
      
      # Draw the solid lines      
      rangey.step(dstepy) do |y|
        point_start   = Point.new(0, space.get_value(y, context.windowspace))
        point_end     = Point.new(context.windowspace.width, space.get_value(y, context.windowspace))
        
        if y % @ystep == 0 
          line_points   << point_start.cap
          line_points   << point_end.cap          
        else      
          division_line_points   << point_start.cap
          division_line_points   << point_end.cap          
        end
      end
      
      # Draw all lines
      context.draw_lines(division_line_points, @division_style)
      context.draw_lines(line_points, @style)
    end
    
  end
  
  # As the BarGrid the BarAxes are the same as the XYAxes in the Y/Value direction. In the data/x direction
  # you can set label (a label for all indices) and labels (an array with a label for every index)
  class BarAxes < Axes
    
    attr_accessor :ystep, :ydiv, :label, :ylabel, :labels, :ysubstitution
  
    def initialize(ystep=10, ydiv=3, label = "Data", ylabel = "Value", labels = Array.new)
      # Init the super class
      super()
      # Init attributes
      @ystep, @ydiv, @label, @ylabel, @labels = ystep, ydiv, label, ylabel, labels
      
      @ysubstitution = nil
      
      # Set the standard style
      @style.tick_size        = 2
    end
  
  protected
  
    def draw_object(context, space)
    
      # Calculate the division step
      dstepy  = @ystep/(@ydiv+1.0)
      # Calculate the offset to put the ticks in the correct position
      yof     = dstepy - (space.yrange.first.to_f % dstepy)
      
      # Calculate the tick ranges
      rangey = (space.yrange.first.to_f + yof) .. space.yrange.last.to_f
      
      tick_line_points  = Array.new
      label_points      = Array.new
      labels            = Array.new
      
      max_label_width   = 0
      
      # Y-Ticks
      rangey.step(dstepy) do |y|
        
        point_start   = Point.new(0, space.get_value(y, context.windowspace)) 
        point_end     = point_start.clone
        
        if y % @ystep == 0 then
          size = @style.tick_size
          
          # Create tick-label
          if @ysubstitution
            labels      << @ysubstitution[y].to_s
          else
            labels        << y.to_s
          end
          label_points  << Point.new(point_end.x - size - 2, point_end.y)
          
          label_size = context.atom_textsize(labels[-1], @style)
          
          # Calculate the width of the labels
          max_label_width = label_size.width if label_size.width > max_label_width
        else
          size = @style.tick_size/2
        end
        
        point_start.x -= size
        point_end.x   += size
        
        tick_line_points   << point_start.cap
        tick_line_points   << point_end.cap
      end
      
      # Draw tick-labels
      context.text_array(labels, label_points, @style, :right, :center)
      
      label_points = Array.new
      
      # Label axis ticks/labels
      
      label_height      = context.atom_textsize(@labels[0], @style).height
      step_size         = context.windowspace.width.to_f/(space.index_range.last-space.index_range.first+1)
      (0..context.windowspace.width+step_size/2).step(step_size) do |x|
        
        point_start   = Point.new(x, -3)
        point_end     = point_start.clone
        point_end.y   += 6
        
        point_label   = Point.new(x+step_size/2, -4)
        
        label_points       << point_label        
        tick_line_points   << point_start.cap
        tick_line_points   << point_end.cap
      end
      
      # Draw tick-labels
      context.text_array(@labels, label_points, @style, :center, :top)

      # Draw all ticks
      context.draw_lines(tick_line_points, @style)
      
      # Y-Axis
      point_start   = Point.new(0, space.get_value(space.yrange.first, context.windowspace))
      point_end     = Point.new(0, space.get_value(space.yrange.last, context.windowspace))
      context.atom_drawline(point_start.cap, point_end.cap, @style)
       
      # Y-Axis Label
      point_end.y  = context.windowspace.height/2
      point_end.x  -= 12 + max_label_width
      
      point_end.cap!
      
      context.atom_text(@ylabel, point_end, @style, :center, :bottom, Rotation.new(-90, point_end.clone))
      
      # Label axis
      point_end.y  = -12-label_height
      point_end.x  = context.windowspace.width/2
      
      point_end.cap!
      
      context.atom_text(@label, point_end, @style, :center, :top)
      
      # X-Axis
      point_start   = Point.new(0, space.get_value(0, context.windowspace))
      point_end     = Point.new(context.windowspace.width, space.get_value(0, context.windowspace))
      context.atom_drawline(point_start.cap, point_end.cap, @style)
      
      # Label-Axis
      point_start   = Point.new(0, 0)
      point_end     = Point.new(context.windowspace.width, 0)
      context.atom_drawline(point_start.cap, point_end.cap, @style)
        
    end
    
  end

  class BarHistorySymbol < HistorySymbol
    
    def draw(dataset, context, text_pos, style)
      symbolstyle             = Style.new
      symbolstyle.fill_color  = dataset.style.fill_color
      symbolstyle.color       = Color.new(0,0,0)
      
      symbolrect              = Rect.new(text_pos.x, text_pos.y, style.symbol_size, style.symbol_size)
      
      context.atom_fillrect(symbolrect, symbolstyle)
    end
    
  end
  
end