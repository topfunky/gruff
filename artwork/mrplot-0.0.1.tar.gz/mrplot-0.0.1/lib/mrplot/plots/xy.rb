# Copyright (c) 2005 Malte Harder, Harderware## Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:## The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

module MRPlot

  # The XYPlot can visualize discrete data and continous functions. It is 
  # initialized with a XYSpace as plot space, XYAxes as axes and a XYGrid as grid.
  #
  # Every dataset must supply data content as a ContinousData object or as an array
  # of hashes with at least two values with the keys :x, :y. If a third value with
  # a :label key is supplied, the label will be printed instead of the
  # Y value.
  #
  # The XYPlot recognizes the following dataset style attributes:
  # print_values_format:: A format how to print the Y values, for example "%.02f"
  # print_values:: If true the values are printed to the dataset's graph
  # hide_connections:: If true only markers (if set) are drawn and no connection lines
  class XYPlot < Plot
    def initialize(title = nil, description = nil)
      super(title,description)
      
      @space          = XYSpace.new
      
      @axes           = XYAxes.new
      @grid           = XYGrid.new
    end
    
    # Sorts the content data (if discrete) by the :x key
    def sort_plot_data(content)
      return content.sort { |a,b| a[:x] <=> b[:x] }
    end
    
    # Converts a value hash to a point
    def get_point_by_val(value)
      return Point.new(value[:x],value[:y])
    end
    
    # Gets a point by using a continous function
    def get_point_by_pos(pos, content)
      # Get a new point in plot space
      newpoint    = @space.transform_to_plotspace(Point.new(pos,0))
      
      # Get y coordinate via the content
      begin
        newpoint.y = content[newpoint.x]
      rescue
        newpoint.y = 0
      end
      
      return newpoint
    end
    
    # Draw the x/y plot
    def draw_naked(context)
      @datasets.each do |dataset|
      
        content = dataset.content
        
        points        = Array.new
        label_points  = Array.new
        labels        = Array.new
        
        if content.class != ContinousData
          points  = Array.new
          
          # Sort the points by their x-coordinate
          data = sort_plot_data(content)
          
          data.each do |value|
            # Get a new point in plot space
            newpoint    = get_point_by_val(value)
            
            # Add label value
            if value[:label] then
              labels      << value[:label]
            elsif dataset.style.print_values_format
              labels      << dataset.style.print_values_format % newpoint.y
            else
              labels      <<  newpoint.y.to_s
            end
            # Add to the list of points
            newpoint      = @space.transform_to_windowspace(newpoint, context.windowspace)
            points        << newpoint
            # Add label point to list
            label_points  << Point.new(newpoint.x, newpoint.y+6)
          end
        else
          # Generate an array of points in windowspace
          pos = 0.0
          # Get the stepsize using the resolution
          step = 1.0/@space.res
          while pos < 1+step
            # Get the corresponding y coordinate to the position
            newpoint      = get_point_by_pos(pos, content)
            
            # Add label value
            if dataset.style.print_values_format
              labels      << dataset.style.print_values_format % newpoint.y
            else
              labels      <<  newpoint.y.to_s
            end
            # Add to the list of points
            newpoint      = @space.transform_to_windowspace(newpoint, context.windowspace)
            points        << newpoint
            # Add label point to list
            label_points  << Point.new(newpoint.x, newpoint.y+6)
            
            # Go to the next point
            pos += step
          end
        end
        
        if dataset.style.marker 
          # Draw markers
          context.draw_markers(points, dataset.style)
        end
        
        if dataset.style.print_values 
          # Draw value labels
          context.text_array(labels, label_points, dataset.style, :center, :bottom)
        end
        
        if !dataset.style.hide_connections
          # Draw the line segments
          context.draw_line_segments(points, dataset.style)
        end
        
      end
    end  
  
  end
  
  # The XYSpace is a linear 2d plot space. The space is specified by a x range and a y range. If you plot continous data the data will be sampled
  # with res samples.
  class XYSpace < PlotSpace
    
    attr_accessor :xrange, :yrange, :res
    
    def initialize(xrange = -10..10, yrange=-10..10, res=200)
      @xrange, @yrange, @res = xrange, yrange, res
    end
    
    def transform_to_unitspace(point2d)
      return Point.new( (point2d.x - @xrange.first)/(@xrange.last - @xrange.first), (point2d.y - @yrange.first)/(@yrange.last - @yrange.first) )
    end
    
    def transform_to_plotspace(point2d)
      return Point.new( (point2d.x*(@xrange.last-@xrange.first)) + @xrange.first, (point2d.y*(@yrange.last-@yrange.first)) + @yrange.first )
    end
    
  end
  
  # The XYGrid is a 2d line/marker grid. You specify the stepsize in X and Y direction and how many substeps (xdiv, ydiv) are made.
  # The sub steps have their own style. If the grid's style attribute Style#solid is true (by default) the grid lines are drawn.
  # If the Style#marker attribute is a valid marker key the markers are drawn.
  class XYGrid < Grid
  
    attr_accessor :xstep, :ystep, :xdiv, :ydiv
    
    # The sub step style
    attr_reader   :division_style
  
    def initialize(xstep=1, ystep=1, xdiv=1, ydiv=1)
      # Init the super class
      super()
      # Init attributes
      @xstep, @ystep, @xdiv, @ydiv = xstep, ystep, xdiv, ydiv
      # Set the standard style
      # @style.marker         = :dot
      @style.solid          = false
      @division_style       = Style.new
      @division_style.solid = false
    end
  
  protected
  
    def draw_object(context, space)
    
      # Calculate the division step
      dstepx  = @xstep/(@xdiv+1.0)
      dstepy  = @ystep/(@ydiv+1.0)
      
      # Calculate the offset to put the markers/lines in the correct position
      xof     = dstepx - (space.xrange.first.to_f % dstepx)
      yof     = dstepy - (space.yrange.first.to_f % dstepy)
      
      # Calculate the marker/line ranges
      rangex = (space.xrange.first.to_f + xof) .. space.xrange.last.to_f
      rangey = (space.yrange.first.to_f + yof) .. space.yrange.last.to_f
      
      # Store markers in an array
      marker_points           = Array.new
      
      # Draw all markers
      if @style.marker
        rangex.step(@xstep) do |x|
          rangey.step(@ystep) do |y|        
              point = space.transform_to_windowspace(Point.new(x,y), context.windowspace)
              marker_points << point.cap           
          end
        end
      end

      # Store solid lines in an array
      line_points             = Array.new
      division_line_points    = Array.new
      
      # Draw the solid lines
      rangex.step(dstepx) do |x|
        point_start   = space.transform_to_windowspace(Point.new(x,space.yrange.first), context.windowspace)
        point_end     = space.transform_to_windowspace(Point.new(x,space.yrange.last), context.windowspace)
        
        if x % @xstep == 0 and style.solid
          line_points   << point_start.cap
          line_points   << point_end.cap
        elsif division_style.solid 
          division_line_points   << point_start.cap
          division_line_points   << point_end.cap
        end
      end
      rangey.step(dstepy) do |y|
        point_start   = space.transform_to_windowspace(Point.new(space.xrange.first,y), context.windowspace)
        point_end     = space.transform_to_windowspace(Point.new(space.xrange.last,y), context.windowspace)
        
        if y % @ystep == 0 and style.solid
          line_points   << point_start.cap
          line_points   << point_end.cap
        elsif division_style.solid 
          division_line_points   << point_start.cap
          division_line_points   << point_end.cap
        end          
      end

      
      # Draw all lines/markers
      context.draw_lines(division_line_points, @division_style)
      context.draw_markers(marker_points, @style)
      context.draw_lines(line_points, @style)
    end
  end
  
  # The XYAxes draws two axes with arrowheads (if Style#arrow_head is set) in positive direction and ticks on them. You specify the tick steps and the subdivision.
  # You can also set label substitutions to change the tick labels. To rotate an axis label set Style#rotate_x or Style#rotate_y to true
  class XYAxes < Axes
    
    attr_accessor :xstep, :ystep, :xdiv, :ydiv, :xlabel, :ylabel, :xsubstitution, :ysubstitution
  
    def initialize(xstep=1, ystep=1, xdiv=1, ydiv=1, xlabel = "X", ylabel = "Y")
      # Init the super class
      super()
      # Init attributes
      @xstep, @ystep, @xdiv, @ydiv, @xlabel, @ylabel = xstep, ystep, xdiv, ydiv, xlabel, ylabel
      
      @xsubstitution = nil
      @ysubstitution = nil
      
      # Set the standard style
      @style.tick_size        = 2
      @style.arrow_head_size  = 7
      @style.arrow_head       = :sharp
    end
  
  protected
  
    def draw_object(context, space)
    
      # Calculate the division step
      dstepx  = @xstep/(@xdiv+1.0)
      dstepy  = @ystep/(@ydiv+1.0)
      
      # Calculate the offset to put the ticks in the correct position
      xof     = dstepx - (space.xrange.first.to_f % dstepx)
      yof     = dstepy - (space.yrange.first.to_f % dstepy)
      
      # Calculate the tick ranges
      rangex = (space.xrange.first.to_f + xof) .. space.xrange.last.to_f
      rangey = (space.yrange.first.to_f + yof) .. space.yrange.last.to_f
      
      tick_line_points  = Array.new
      label_points      = Array.new
      labels            = Array.new
      
      # X-Ticks
      rangex.step(dstepx) do |x|
        
        point_start   = space.transform_to_windowspace(Point.new(x,0), context.windowspace)
        point_end     = point_start.clone
      
        if x % @xstep == 0 then
          size = @style.tick_size
          
          if x != 0 then
            # Create tick-label
            if @xsubstitution
              labels      << @xsubstitution[x].to_s
            else
              labels        << x.to_s
            end
            label_points  << Point.new(point_end.x, point_end.y + size + 2)
          end      
          
        else
          size = @style.tick_size/2
        end
        
        point_start.y -= size
        point_end.y   += size
        
        
        tick_line_points   << point_start.cap
        tick_line_points   << point_end.cap
      end
      
      # Draw tick-labels
      context.text_array(labels, label_points, @style, :center)
      
      label_points      = Array.new
      labels            = Array.new
      
      # Y-Ticks
      rangey.step(dstepy) do |y|
        
        point_start   = space.transform_to_windowspace(Point.new(0, y), context.windowspace)
        point_end     = point_start.clone
        
        if y % @ystep == 0 then
          size = @style.tick_size
          
          if y != 0 then
            # Create tick-label
            if @ysubstitution
              labels      << @ysubstitution[y].to_s
            else
              labels        << y.to_s
            end
            label_points  << Point.new(point_end.x + size + 2, point_end.y)
          end
          
        else
          size = @style.tick_size/2
        end
        
        point_start.x -= size
        point_end.x   += size
        
        tick_line_points   << point_start.cap
        tick_line_points   << point_end.cap
      end
      
      # Draw tick-labels
      context.text_array(labels, label_points, @style, :left, :center)
      
      # Draw all ticks
      context.draw_lines(tick_line_points, @style)
      
      # X-Axis
      point_start   = space.transform_to_windowspace(Point.new(space.xrange.first,0), context.windowspace)
      point_end     = space.transform_to_windowspace(Point.new(space.xrange.last,0), context.windowspace)
      context.atom_drawline(point_start.cap, point_end.cap, @style)
      
      # X-Axis Label
      point_end.y  -= 3
      point_end.x  -= 2 + @style.arrow_head_size
      
      point_end.cap!
      
      if @style.rotate_x then
        context.atom_text(@xlabel, point_end, @style, :left, :top, Rotation.new(90, point_end.clone) )
      else
        context.atom_text(@xlabel, point_end, @style, :right, :top)
      end
            
      # Y-Axis
      point_start   = space.transform_to_windowspace(Point.new(0,space.yrange.first), context.windowspace)
      point_end     = space.transform_to_windowspace(Point.new(0,space.yrange.last), context.windowspace)
      context.atom_drawline(point_start.cap, point_end.cap, @style)
      
      # Y-Axis Label
      point_end.y  -= 2 + @style.arrow_head_size
      point_end.x  -= 3
      
      point_end.cap!
      
      if @style.rotate_y then
        context.atom_text(@ylabel, point_end, @style, :left, :top, Rotation.new(90, point_end.clone))
      else
        context.atom_text(@ylabel, point_end, @style, :right, :top)
      end
        
      # Arrowheads X/Y
      if @style.arrow_head
        point       = space.transform_to_windowspace(Point.new(space.xrange.last,0), context.windowspace)
        context.atom_arrow_head(point.cap, :xarrow, @style)
        
        point   = space.transform_to_windowspace(Point.new(0,space.yrange.last), context.windowspace)
        context.atom_arrow_head(point.cap, :yarrow, @style)
      end
    end
    
  end
  
end