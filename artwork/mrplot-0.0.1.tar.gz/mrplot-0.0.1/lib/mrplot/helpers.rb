# Copyright (c) 2005 Malte Harder, Harderware
#
# Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:
#
# The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

module DeepCopy
  def clone
    Marshal.load(Marshal.dump(self))
  end
end

# MRPHelpers contains helper classes for the mrplot library
module MRPHelpers

  # The Rotation class is used to rotate a text around a specified point
  class Rotation
    attr_accessor :angle, :origin
  
    def initialize(angle = 90, origin = Point.new(0,0))
      @angle  = angle
      @origin = origin
    end
  end
  
  # Substitutions are used to replace the axes' labels for example with string or
  # another scale.
  class Substitution
    
    # :call-seq:
    #   new(hash)
    #   new() { |value| ... }
    #
    # You can create a subtitution with a hash or a block
    def initialize(hash=nil, &substitution)
      @hash = hash
      @substitution = substitution
    end
    
    def [](value)
      if @hash
        return @hash[value]
      else
        return @substitution.call(value)
      end
    end
    
  end
  
  # The Color class is used for all styles which are using colors.
  # All values should be in the range 0..1.0
  class Color
    attr_accessor :red, :green, :blue, :alpha
    def initialize(red=0.0,green=0.0,blue=0.0,alpha=0.0)
      @red    = red
      @green  = green
      @blue   = blue
      @alpha  = alpha
    end
  end
  
  # A style is a hash but you don't access it by the [] operator. You can call directly:
  #
  #  style_a.<whateveryouwant>=     "Hallo"
  #  style_a.<whateveryouwant>  ->  "Hallo"
  class Style
  
    # Core Style Values
    attr_reader :styles
    def initialize
      @styles                 = Hash.new  
    end
  
    def method_missing(symbol, *args)
      if hash_value = symbol.id2name.sub!(/\Aset_/, "")
        @styles[hash_value] = args[0]
      elsif symbol.id2name[-1,1] == "="
        hash_value = symbol.id2name
        hash_value[-1,1]=""
        @styles[hash_value] = args[0]
      else
        return @styles[symbol.id2name]
      end
    end
    
    # Clear the style
    def clear
      @styles = Hash.new
    end
    
    def to_s
      @styles.to_s
    end
    
  end
  
  # A floating point 2 dimensional coordinate
  class Point
    include DeepCopy
  
    attr_accessor :x, :y
    
    # Convert a size to a point
    def Point.fromsize(size)
      Point.new(size.width, size.height)
    end
    
    def initialize(x,y)
      @x = x.to_f
      @y = y.to_f
    end
    
    def to_s
      return "(#{@x},#{@y})"
    end 
    
    # Does x.round and y.round
    def cap!
      @x = @x.round
      @y = @y.round
    end
    
    def cap
      result = self.clone
      result.cap!
      return result
    end
    
  end
  
  # A 2d floating point size
  class Size
    attr_accessor :width, :height
    
    # Convert a point to size
    def Size.frompoint(point)
      Size.new(point.x, point.y)
    end
    
    def initialize(width, height)
      @width  = width
      @height = height
    end
    
    def area
      @width*@height
    end
    
    def perimeter
      2*(@width+@height)
    end
    
    def to_s
      return "[#{@width},#{@height}]"
    end 
    
  end
  
  class Border
    attr_accessor :top, :bottom, :left, :right
    
    def initialize(top, bottom, left, right)
      @top, @bottom, @left, @right = top, bottom, left, right
    end
    
    def to_s
      return "|#{@top},#{@bottom},#{@left},#{@right}|"
    end
  
  end
  
  class Rect
    
    include DeepCopy
    
    attr_reader :origin, :size
    
    # Creates a rect with origin at 0,0
    def Rect.fromsize(size)
      Rect.new(0,0,size.width,size.height)
    end
    
    def initialize(x,y,width,height)
      @origin = Point.new(x,y)
      @size   = Size.new(width,height)
    end
    
    def x
      @origin.x
    end
    
    def y
      @origin.y
    end
    
    def width
      @size.width
    end
    
    def height
      @size.height
    end
    
    # The extent is the second point of the rect (x+width, y+height)
    def extent
      Point.new(x2,y2)
    end
    
    def x2
      @origin.x+@size.width
    end
    
    def y2
      @origin.y+@size.height
    end
    
    # Extends the rect by a border
    def extend!(border)
      @origin.x -= border.left
      @origin.y -= border.bottom
      
      @size.width   += border.left  + border.right
      @size.height  += border.top   + border.bottom
      
      return self
    end
    
    # Cut a border from a rect
    def cut!(border)
      @origin.x += border.left
      @origin.y += border.bottom
      
      @size.width   -= border.left  + border.right
      @size.height  -= border.top   + border.bottom
      return self
    end
    
    # :call-seq:
    #   extend(border) -> Rect
    #
    # See Rect#extend!(border)
    def extend(border)
      result = self.clone
      result.extend!(border)
      return result
    end
    
    # :call-seq:
    #   cut(border) -> Rect
    #
    # See Rect#cut!(border)
    def cut(border)
      result = self.clone
      result.cut!(border)
      return result
    end
    
    def to_s
      return "{#{@origin},#{@size}}"
    end 
    
  end
end