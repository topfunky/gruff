# Copyright (c) 2005 Malte Harder, Harderware## Permission is hereby granted, free of charge, to any person 
# obtaining a copy of this software and associated documentation 
# files (the "Software"), to deal in the Software without 
# restriction, including without limitation the rights to use, 
# copy, modify, merge, publish, distribute, sublicense, and/or 
# sell copies of the Software, and to permit persons to whom the 
# Software is furnished to do so, subject to the following 
# conditions:## The above copyright notice and this permission notice shall be 
# included in all copies or substantial portions of the 
# Software.## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY 
# KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
# WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
# PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
# COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
# OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

require 'RMagick'

module MRPHelpers
  class Color

    # Convert the color to a RMaick conform color string
    def to_rgba
      return "rgba(#{@red*100}%,#{@green*100}%,#{@blue*100}%,#{@alpha*100}%)"
    end
    
  end
end

module MRPlot



# The RMagick context, uses RMagick/ImageMagick to output plots as images
class RMagickContext < GraphicContext
    include Magick
    
    attr_reader :image
    
    # Create new context (image) with the size in pixels
    def initialize(size)
      super(size)
      @image  = Image.new(size.width, size.height)
      @gc     = Draw.new
      
      @image_cache = Hash.new
      @pattern_cache = Hash.new
      
      # Define the context clipping path
      @gc.define_clip_path("all") { @gc.rectangle(0,0, size.width, size.height) }
      @gc.clip_path("all")
    end
        
    # Overwrites the windowspace attr writer to update the context clipping
    def windowspace=(value)
      # Change the window clipping path
      @windowspace = value

      @gc.define_clip_path("window") do
        @gc.rectangle(@windowspace.x, @windowspace.y,  \
                        @windowspace.x+@windowspace.width, @windowspace.y+@windowspace.height)
      end
    end
    
    # Overwrites the clip attr writer to update the context clipping
    def clip=(value)
      # Switch the clipping path
      @clip = value
      if @clip
        @gc.clip_path("window")
      else
        @gc.clip_path("all")
      end
    end
    
    def placeholder(rect)
      # Set color/stroke
      @gc.fill_opacity(0)
      @gc.stroke('black')
      @gc.stroke_width(1)
      
      # Draw crossed rectangle      
      p1 = transform(rect.origin)
      p2 = transform(rect.extent)
      
      @gc.rectangle(p1.x,p1.y, p2.x,p2.y)
      @gc.line(p1.x,p1.y, p2.x,p2.y)
      @gc.line(p1.x,p2.y, p2.x,p1.y)
    end
      
    def atom_text(string, point, style, rel = :left, rel_v = :bottom, rotate = nil)
      
      return if point.y.to_f.nan?
      
      point = transform(point)
      
      applystyle(@gc, style, :font)
      size = atom_textsize(string, style)
      
      if rel_v == :center
        point.y += size.height/2
      elsif rel_v == :top
        point.y += size.height
      end
      
      if rel == :left
        @gc.text_align(Magick::LeftAlign)
      elsif rel == :center
        @gc.text_align(Magick::CenterAlign)
      elsif rel == :right
        @gc.text_align(Magick::RightAlign)
      end
      
      point.cap!
      
      if rotate
        rotpoint = transform(rotate.origin)
        @gc.translate(rotpoint.x, rotpoint.y)
        @gc.rotate(rotate.angle)
        @gc.text(point.x-rotpoint.x, point.y-rotpoint.y, string.inspect)
        @gc.rotate(-rotate.angle)
        @gc.translate(-rotpoint.x, -rotpoint.y)
      else
        @gc.text(point.x, point.y, string.inspect)
      end
    end
    
    def atom_textsize(string, style)
      # TODO Incorrect value
      applystyle(@gc, style, :font)
  
      metrics = @gc.get_type_metrics(@image, string )
      return Size.new(metrics.width, metrics.ascent)
    end
    
    def atom_drawline(point_start, point_end, style)
      
      return if point_start.y.to_f.nan? or point_end.y.to_f.nan?
      
      point_start = transform(point_start)
      point_end   = transform(point_end)
      
      applystyle(@gc, style, :line)
      @gc.line(point_start.x, point_start.y, point_end.x, point_end.y)
    end
    
    def atom_drawrect(rect, style)
      
      point_start = transform(rect.origin)
      point_end   = transform(rect.extent)
      
      applystyle(@gc, style, :stroke)
      @gc.rectangle(point_start.x, point_start.y, point_end.x, point_end.y)
    end
    
    def atom_fillrect(rect, style)
      
      point_start = transform(rect.origin)
      point_end   = transform(rect.extent)
      
      applystyle(@gc, style, :area)
      @gc.rectangle(point_start.x, point_start.y, point_end.x, point_end.y)
    end
    
    # Draw a marker. The following markers (Style#marker)  are supported :dot, :small_cross, :cross, :square, 
    # :circle, :image. If you use :image you have to specify the image's filename in Style#marker_image.
    def atom_marker(point, style)
      
      return if point.y.to_f.nan?
      
      point = transform(point).cap
      
      if style.marker == :dot then
        applystyle(@gc, style, :line)
        @gc.line(point.x, point.y, point.x, point.y)
      elsif style.marker == :small_cross
        applystyle(@gc, style, :line)
        @gc.line(point.x-2, point.y, point.x+2, point.y)
        @gc.line(point.x, point.y+2, point.x, point.y-2)
      elsif style.marker == :cross
        applystyle(@gc, style, :line)
        @gc.line(point.x-3, point.y-3, point.x+3, point.y+3)
        @gc.line(point.x-3, point.y+3, point.x+3, point.y-3)
      elsif style.marker == :square
        applystyle(@gc, style, :stroke)
        @gc.rectangle(point.x-3, point.y-3, point.x+3, point.y+3)
      elsif style.marker == :circle
        applystyle(@gc, style, :stroke)
        @gc.circle(point.x, point.y, point.x+3, point.y)
      elsif style.marker == :image
        if style.marker_image 
          if !@image_cache[style.marker_image]
            @image_cache[style.marker_image] = ImageList.new(style.marker_image)
          end
          
          img     = @image_cache[style.marker_image]
          width   = img.columns
          height  = img.rows
          
          @gc.composite(point.x-width/2, point.y-height/2, 0,0, img)
        end
      end
    end
    
    # Draws an arrow head. Currently the RMagickContext only supports one type of arrow heads so 
    # the Style#arrow_head attribute will be ignored
    def atom_arrow_head(point, align, style)
      
      points = Array.new(4) {point.clone}
      result = Array.new
      
      if align == :xarrow
        
        points[1].x -= style.arrow_head_size
        points[1].y += style.arrow_head_size*0.4
        
        points[3].x -= style.arrow_head_size
        points[3].y -= style.arrow_head_size*0.4
        
        points[2].x -= style.arrow_head_size*0.75
      else
        points[1].y -= style.arrow_head_size
        points[1].x += style.arrow_head_size*0.4
        
        points[3].y -= style.arrow_head_size
        points[3].x -= style.arrow_head_size*0.4
        
        points[2].y -= style.arrow_head_size*0.75
      end
    
      points.each do |point| 
        temp =  transform(point)
        result << temp.x
        result << temp.y
      end
      
      applystyle(@gc, style, :area)
      @gc.polygon(*result)
      
    end
    
    # This is a optimized draw_line_segments method which uses the RMagick's Draw#polyline method.
    def draw_line_segments(points, style)
      if !style.single_lines then    
        
        line = Array.new
        
        points.each do |point|
          temp = transform(point)
          
          next if temp.y.to_f.nan?
                    
          line << temp.x
          line << temp.y
        end
        
        applystyle(@gc, style, :line)
        @gc.polyline(*line)
      else
        super(points, style)
      end
    end
    
    # Writes the context to a image file. Uses RMagick's Image#write method. The file format can be specified by using the formats extension (.jpg, .png and so on)
    def write(filename)
      @gc.draw(@image)
      @image.write(filename)
    end
    
    def corecontext
      @image
    end
    
  protected
    
    # Apply standard styles to context use :line/:stroke, :font or :area as type argument to get the correct mapping of the style's color/fill_color attributes to 
    # the internal context states
    def applystyle(gc,style, type = :line)      
      # If the style is applied to line drawing
      if type == :line or type == :stroke then
        if !style.line_width 
          style.line_width = 1
        end

        gc.stroke_width(style.line_width)          
        gc.fill('none')
        
        if style.color
          gc.stroke(style.color.to_rgba)     
        else
          gc.stroke('black')
        end
      # If the style is applied to font drawing
      elsif type == :font
        if style.font
          gc.font(style.font)
        else
          gc.font('Helvetica')
        end
        
        if style.font_size
          gc.font_size(style.font_size)
        else
          gc.font_size(12)
        end
        
        gc.stroke('none')
    
        if style.color
          gc.fill(style.color.to_rgba)
        else
          gc.fill('black')
        end 
      # If the style is applied to area drawings   
      elsif type == :area
        if style.color
          gc.stroke(style.color.to_rgba)     
        else
          gc.stroke('black')
        end
      
        if style.fill_color
          gc.fill(style.fill_color.to_rgba)
        else
          gc.fill('black')
        end
        
        if style.line_width
          gc.stroke_width(style.line_width)
        else
          gc.stroke_width(1.0)
        end
      end
      
      if style.dashed 
        gc.stroke_dasharray(*style.dashed)
      else
        gc.stroke_dasharray()
      end
      
    end
    
  end
end